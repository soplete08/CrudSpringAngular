package com.vick.springmysqlbarcos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMySqlBarcosApplicationTests {

	@Test
	void contextLoads() {
	}

}
