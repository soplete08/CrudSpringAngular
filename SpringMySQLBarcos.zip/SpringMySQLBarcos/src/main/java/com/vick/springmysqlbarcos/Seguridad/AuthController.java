package com.vick.springmysqlbarcos.Seguridad;


import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@RequestBody LoginRequest request){

        return ResponseEntity.ok(authService.login(request));
    }

    @PostMapping( "/register")
    public ResponseEntity<AuthResponse> register(@RequestBody LoginRequest request){
        return ResponseEntity.ok(authService.register(request));
    }
}
