package com.vick.springmysqlbarcos.servicios;

import com.vick.springmysqlbarcos.Datos.Barcos;
import com.vick.springmysqlbarcos.Datos.Salidas;
import com.vick.springmysqlbarcos.Datos.Socios;
import com.vick.springmysqlbarcos.Excepciones.ResourceNotFoundException;
import com.vick.springmysqlbarcos.Repositorio.BarcosRepositorio;
import com.vick.springmysqlbarcos.Repositorio.SalidasRepositorio;
import com.vick.springmysqlbarcos.dto.BarcosDTO;
import com.vick.springmysqlbarcos.dto.SalidasDTO;
import com.vick.springmysqlbarcos.dto.SalidasRespuesta;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

@Service
public class SalidasServiciosImpl implements SalidasServicio {

    @Autowired
    SalidasRepositorio salidasRepositorio;

    @Autowired
    BarcosRepositorio barcosRepositorio;

    @Autowired
    private ModelMapper modelMapper;
    @Override
     public SalidasDTO crearSalida
            (SalidasDTO salidasdto){
        salidasdto.setHoraSalida(Calendar.getInstance());
        //pasamos de dto a entidad
        Salidas salida=mapearEntidad(salidasdto);
        salida.setMatriculas(barcosRepositorio.findById(salidasdto.getMatriculas()).get());

        Salidas nuevaSalida= salidasRepositorio.save(salida);

        //de entidad a dto
        SalidasDTO salidarespuesta = mapearDTO(nuevaSalida);
        return salidarespuesta;
    }

    @Override
    public SalidasRespuesta obtenerTodasLasSalidas() {
        SalidasRespuesta salidasRespuesta = new SalidasRespuesta();
        List<Salidas> salidas = salidasRepositorio.findAll();
        
        List<SalidasDTO> salidasDTO=new ArrayList<>() {
        };
        
        for(Salidas b:salidas){
            salidasDTO.add(mapearDTO(b));
        }
        salidasRespuesta.setSalidasTodas(salidasDTO);
        return salidasRespuesta;
    }

    @Override
    public SalidasDTO obtenerSalidasPorId(int id) {
        Salidas salidas = salidasRepositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("salida", "id", id));
        return mapearDTO(salidas);
    }

    @Override
    public void eliminarSalidas(int id) {
        Salidas salida = salidasRepositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("salida", "id", id));
        salidasRepositorio.delete(salida);
    }

    @Override
    public List<SalidasDTO> obtenerTodasLasSalidasListas() {
        SalidasRespuesta salidasRespuesta = new SalidasRespuesta();
        List<Salidas> salidas = salidasRepositorio.findAll();

        List<SalidasDTO> salidasDTO=new ArrayList<>() {
        };

        for(Salidas b:salidas){
            salidasDTO.add(mapearDTO(b));
        }
        return salidasDTO;
    }

    /*



            MAPEO



             */
    private SalidasDTO mapearDTO(Salidas salida){

        return modelMapper.map(salida,SalidasDTO.class);
    }

    private List<SalidasDTO> mapearDTO(List<Salidas> salida){
        List<SalidasDTO> sDTO = null;
        for(Salidas s:salida){
            sDTO.add(modelMapper.map(s,SalidasDTO.class));
        }

        return sDTO;
    }
    private Salidas mapearEntidad(SalidasDTO salidasDTO){
        return modelMapper.map(salidasDTO,Salidas.class);
    }


}
