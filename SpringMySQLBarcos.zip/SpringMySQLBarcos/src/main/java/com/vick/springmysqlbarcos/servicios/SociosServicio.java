package com.vick.springmysqlbarcos.servicios;

import com.vick.springmysqlbarcos.dto.SociosDTO;
import com.vick.springmysqlbarcos.dto.SociosRespuesta;

import java.util.List;

public interface SociosServicio {
    public SociosDTO crearSocio(SociosDTO sociodto);
    public SociosRespuesta obtenerTodosLosSocios();
    public List<SociosDTO> obtenerTodosLosSociosLista();
    public SociosDTO obtenerSocioPorId(int id);
    public void eliminarSocio(int id);

}
