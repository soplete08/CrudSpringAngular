package com.vick.springmysqlbarcos.dto;

import com.vick.springmysqlbarcos.Datos.Barcos;
import com.vick.springmysqlbarcos.Datos.Salidas;

import java.util.ArrayList;
import java.util.List;

public class BarcosDTO {
    private String matricula;
    private String nombre;
    private int nAmarre;
    private int cuota;
    private int idSocio;

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getnAmarre() {
        return nAmarre;
    }

    public void setnAmarre(int nAmarre) {
        this.nAmarre = nAmarre;
    }

    public int getCuota() {
        return cuota;
    }

    public void setCuota(int cuota) {
        this.cuota = cuota;
    }

    public int getIdSocio() {
        return idSocio;
    }

    public void setIdSocio(int idSocio) {
        this.idSocio = idSocio;
    }

}

