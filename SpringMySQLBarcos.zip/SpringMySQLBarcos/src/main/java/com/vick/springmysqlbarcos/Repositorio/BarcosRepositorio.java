package com.vick.springmysqlbarcos.Repositorio;

import com.vick.springmysqlbarcos.Datos.Barcos;
import com.vick.springmysqlbarcos.Datos.Socios;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BarcosRepositorio extends JpaRepository<Barcos, String> {

}
