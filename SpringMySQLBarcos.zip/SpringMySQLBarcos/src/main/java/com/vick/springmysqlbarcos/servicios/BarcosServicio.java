package com.vick.springmysqlbarcos.servicios;

import com.vick.springmysqlbarcos.dto.BarcosDTO;
import com.vick.springmysqlbarcos.dto.BarcosRespuesta;
import com.vick.springmysqlbarcos.dto.SociosDTO;

import java.util.List;

public interface BarcosServicio {
    public BarcosDTO crearBarco(BarcosDTO barcosDTO);
    public BarcosRespuesta obtenerTodosLosbarcos();
    public List<BarcosDTO> obtenerTodosLosbarcosLista();
    public BarcosDTO obtenerBarcoPorMatricula(String matricula);
    public void eliminarBarco(String matricula);

}
