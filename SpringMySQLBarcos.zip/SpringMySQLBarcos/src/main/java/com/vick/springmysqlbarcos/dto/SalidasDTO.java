package com.vick.springmysqlbarcos.dto;

import com.vick.springmysqlbarcos.Datos.Barcos;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class SalidasDTO {
    private int id;
    private Calendar horaSalida;
    private String destino;
    private String patron;
    private String matriculas;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Calendar getHoraSalida() {
        return horaSalida;
    }

    public void setHoraSalida(Calendar horaSalida) {
        this.horaSalida = horaSalida;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public String getPatron() {
        return patron;
    }

    public void setPatron(String patron) {
        this.patron = patron;
    }

    public String getMatriculas() {
        return matriculas;
    }

    public void setMatriculas(String matriculas) {
        this.matriculas = matriculas;
    }
}
