package com.vick.springmysqlbarcos.controlador;

import com.vick.springmysqlbarcos.dto.BarcosDTO;
import com.vick.springmysqlbarcos.dto.BarcosRespuesta;
import com.vick.springmysqlbarcos.dto.SociosDTO;
import com.vick.springmysqlbarcos.servicios.BarcosServicio;
import com.vick.springmysqlbarcos.servicios.SociosServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin
@RestController
@RequestMapping("/api/barcos")
public class BarcosControlador {
    @Autowired
    private BarcosServicio barcosServicio;

    @PostMapping
    public ResponseEntity<BarcosDTO> guardarBarco(@RequestBody BarcosDTO barcosDTO){
        barcosServicio.crearBarco(barcosDTO);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }


    @DeleteMapping("/{matricula}")
    public ResponseEntity<String> eliminarBarco(@PathVariable(name ="matricula")String matricula) {
    barcosServicio.eliminarBarco(matricula);
    return new ResponseEntity<>(HttpStatus.OK);
    }


    @GetMapping("/all")
    public BarcosRespuesta listarbarco(){
        return barcosServicio.obtenerTodosLosbarcos();
    }

    @GetMapping("/allall")
    public List<BarcosDTO> listarBarcosListas(){
        return barcosServicio.obtenerTodosLosbarcosLista();
    }

    @GetMapping("/{matricula}")
    public ResponseEntity<BarcosDTO> obtenerBarcoPorId(@PathVariable(name ="matricula")String matricula){
        return ResponseEntity.ok(barcosServicio.obtenerBarcoPorMatricula(matricula));
    }
}
