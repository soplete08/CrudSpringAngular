package com.vick.springmysqlbarcos.controlador;

import com.vick.springmysqlbarcos.dto.BarcosDTO;
import com.vick.springmysqlbarcos.dto.SalidasDTO;
import com.vick.springmysqlbarcos.dto.SalidasRespuesta;
import com.vick.springmysqlbarcos.servicios.BarcosServicio;
import com.vick.springmysqlbarcos.servicios.SalidasServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin
@RestController
@RequestMapping("/api/salidas")
public class SalidasControlador {
    @Autowired
    private SalidasServicio salidasServicio;

    @PostMapping
    public ResponseEntity<SalidasDTO> guardarSalidas(@RequestBody SalidasDTO salidasDTO){
        salidasServicio.crearSalida(salidasDTO);
        return new ResponseEntity<>( HttpStatus.CREATED);
    }


    @GetMapping("/all")
    public SalidasRespuesta listarSalidas(){
        return salidasServicio.obtenerTodasLasSalidas();
    }

    @GetMapping("/allall")
    public List<SalidasDTO> listarSalidasListas(){
        return salidasServicio.obtenerTodasLasSalidasListas();
    }

    @GetMapping("/{id}")
    public ResponseEntity<SalidasDTO> obtenerSalidasPorMatricula(@PathVariable(name ="id")int id){
        return ResponseEntity.ok(salidasServicio.obtenerSalidasPorId(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminarSalidas(@PathVariable(name ="id")int id) {
        salidasServicio.eliminarSalidas(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }


}
