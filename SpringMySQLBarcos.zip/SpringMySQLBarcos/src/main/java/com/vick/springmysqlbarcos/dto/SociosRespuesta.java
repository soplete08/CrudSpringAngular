package com.vick.springmysqlbarcos.dto;

import java.util.List;

public class SociosRespuesta {
    private List<SociosDTO> sociosTodas;

    public List<SociosDTO> getSociosTodas() {
        return sociosTodas;
    }

    public void setSociosTodas(List<SociosDTO> sociosTodas) {
        this.sociosTodas = sociosTodas;
    }
}
