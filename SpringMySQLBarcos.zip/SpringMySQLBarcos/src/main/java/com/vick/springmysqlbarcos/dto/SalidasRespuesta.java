package com.vick.springmysqlbarcos.dto;

import java.util.List;

public class SalidasRespuesta {
    private List<SalidasDTO> salidasTodas;

    public List<SalidasDTO> getSalidasTodas() {
        return salidasTodas;
    }

    public void setSalidasTodas(List<SalidasDTO> salidasTodas) {
        this.salidasTodas = salidasTodas;
    }

}
