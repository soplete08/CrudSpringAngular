package com.vick.springmysqlbarcos.servicios;

import com.vick.springmysqlbarcos.dto.BarcosDTO;
import com.vick.springmysqlbarcos.dto.SalidasDTO;
import com.vick.springmysqlbarcos.dto.SalidasRespuesta;

import java.util.List;

public interface SalidasServicio {
    public SalidasDTO crearSalida(SalidasDTO salidasDTO);
    public SalidasRespuesta obtenerTodasLasSalidas();
    public List<SalidasDTO> obtenerTodasLasSalidasListas();
    public SalidasDTO obtenerSalidasPorId(int id);
    public void eliminarSalidas(int id);


}
