package com.vick.springmysqlbarcos.controlador;

import com.vick.springmysqlbarcos.dto.SalidasDTO;
import com.vick.springmysqlbarcos.dto.SalidasRespuesta;
import com.vick.springmysqlbarcos.dto.SociosDTO;
import com.vick.springmysqlbarcos.dto.SociosRespuesta;
import com.vick.springmysqlbarcos.servicios.SociosServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin
@RestController
@RequestMapping("/api/socios")
public class SociosControlador {
    @Autowired
    private SociosServicio sociosServicio;

    @PostMapping
    public ResponseEntity<SociosDTO> guardarSocio(@RequestBody SociosDTO sociosDTO){
        sociosServicio.crearSocio(sociosDTO);
        return new ResponseEntity<>( HttpStatus.CREATED);
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminarSocio(@PathVariable(name ="id")int id) {
    sociosServicio.eliminarSocio(id);
    return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/all")
    public SociosRespuesta listarSalidas() {
        return sociosServicio.obtenerTodosLosSocios();

    }
    @GetMapping("/allall")
    public List<SociosDTO> listarSalidasListas(){
        return sociosServicio.obtenerTodosLosSociosLista();
    }

    @GetMapping("/{id}")
    public ResponseEntity<SociosDTO> obtenerSocioPorId(@PathVariable(name ="id")int id){
        return ResponseEntity.ok(sociosServicio.obtenerSocioPorId(id));
    }
}
