package com.vick.springmysqlbarcos.Datos;


import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;

import java.io.Serializable;
import java.util.Calendar;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "Salidas")
public class Salidas implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column
    private int id;
    @Column
    //se asigna automaticamente con la fecha actual, no se puede cambiar
    private Calendar horaSalida;

    @Column
    private String destino;

    @Column
    private String patron;

    @ManyToOne
    @NotNull
    @JoinColumn
    private Barcos matriculas;



    public Salidas() {
    }


    public Salidas(int id,Barcos matricula, String destino, String patron) {
        this.matriculas = matricula;
        this.horaSalida = Calendar.getInstance();
        this.destino = destino;
        this.patron = patron;
        List<Salidas> l=matriculas.getSalidasList();
        l.add(this);
        matriculas.setSalidasList(l);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Calendar getHoraSalida() {
        return horaSalida;
    }

    public void setHoraSalida(Calendar horaSalida) {
        this.horaSalida = horaSalida;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public String getPatron() {
        return patron;
    }

    public void setPatron(String patron) {
        this.patron = patron;
    }

    public Barcos getMatriculas() {
        return matriculas;
    }

    public void setMatriculas(Barcos matricula) {
        this.matriculas = matricula;
    }

    @Override
    public String toString() {
        return "Salida " + horaSalida.getTime().toString() + " sale la embarcacion "+ matriculas.getMatricula() + " con el patron " + patron+ " y con destino "+ destino+ "\n";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Salidas salidas = (Salidas) o;
        return Objects.equals(matriculas, salidas.matriculas) && Objects.equals(horaSalida, salidas.horaSalida) && Objects.equals(destino, salidas.destino) && Objects.equals(patron, salidas.patron);
    }

    @Override
    public int hashCode() {
        return Objects.hash(matriculas, horaSalida.getTime().toString(), destino, patron);
    }
}
