package com.vick.springmysqlbarcos.servicios;

import com.vick.springmysqlbarcos.Datos.Socios;
import com.vick.springmysqlbarcos.Excepciones.ResourceNotFoundException;
import com.vick.springmysqlbarcos.Repositorio.SociosRepositorio;
import com.vick.springmysqlbarcos.dto.SalidasDTO;
import com.vick.springmysqlbarcos.dto.SociosDTO;
import com.vick.springmysqlbarcos.dto.SociosRespuesta;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class SociosServiciosImpl implements SociosServicio {

    @Autowired
    SociosRepositorio sociosRepositorio;

    @Autowired
    private ModelMapper modelMapper;
    @Override
     public SociosDTO crearSocio(SociosDTO sociodto){
        //pasamos de dto a entidad
        Socios socio=mapearEntidad(sociodto);

        Socios nuevoSocio=sociosRepositorio.save(socio);

        //de entidad a dto
        SociosDTO sociorespuesta = mapearDTO(nuevoSocio);
        return sociorespuesta;
    }

    @Override
    public SociosRespuesta obtenerTodosLosSocios() {
        SociosRespuesta sociosRespuesta= new SociosRespuesta();
        List<Socios> socios = sociosRepositorio.findAll();
        List<SociosDTO> sociosDTOSalida = new ArrayList<>();

        for(Socios s:socios){
            sociosDTOSalida.add(mapearDTO(s));
        }
        sociosRespuesta.setSociosTodas(sociosDTOSalida);
        return sociosRespuesta;
    }

    @Override
    public List<SociosDTO> obtenerTodosLosSociosLista() {
        List<Socios> socios = sociosRepositorio.findAll();
        List<SociosDTO> sociosDTOSalida = new ArrayList<>();

        for(Socios s:socios){
            sociosDTOSalida.add(mapearDTO(s));
        }
        return sociosDTOSalida;
    }

    @Override
    public SociosDTO obtenerSocioPorId(int id) {
        Socios socio = sociosRepositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("socio", "id", id));
        return mapearDTO(socio);
    }

    @Override
    public void eliminarSocio(int id) {
        Socios socio = sociosRepositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("socios", "id", id));
        sociosRepositorio.delete(socio);

    }



    /*



    MAPEO



     */
    private SociosDTO mapearDTO(Socios socio){

        return modelMapper.map(socio,SociosDTO.class);
    }
    private Socios mapearEntidad(SociosDTO sociosDTO){
        return modelMapper.map(sociosDTO,Socios.class);
    }


}
