package com.vick.springmysqlbarcos.Repositorio;

import com.vick.springmysqlbarcos.Datos.Barcos;
import com.vick.springmysqlbarcos.Datos.Salidas;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Calendar;

public interface SalidasRepositorio extends JpaRepository<Salidas, Integer> {

}
