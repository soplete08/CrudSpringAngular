package com.vick.springmysqlbarcos.servicios;

import com.vick.springmysqlbarcos.Datos.Barcos;
import com.vick.springmysqlbarcos.Datos.Socios;
import com.vick.springmysqlbarcos.Excepciones.ResourceNotFoundException;
import com.vick.springmysqlbarcos.Repositorio.BarcosRepositorio;
import com.vick.springmysqlbarcos.Repositorio.SociosRepositorio;
import com.vick.springmysqlbarcos.dto.BarcosDTO;
import com.vick.springmysqlbarcos.dto.BarcosRespuesta;
import com.vick.springmysqlbarcos.dto.SociosDTO;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class BarcosServiciosImpl implements BarcosServicio {

    @Autowired
    BarcosRepositorio barcosRepositorio;

    @Autowired
    SociosRepositorio sociosRepositorio;

    @Autowired
    private ModelMapper modelMapper;
    @Override
     public BarcosDTO crearBarco(BarcosDTO barcosdto){
        //pasamos de dto a entidad
        Barcos barco=mapearEntidad(barcosdto);
       // barco.setIdSocio(sociosRepositorio.getById(barcosdto.getIdSocio()));

        Barcos nuevoBarco= barcosRepositorio.save(barco);

        //de entidad a dto
        BarcosDTO barcorespuesta = mapearDTO(nuevoBarco);
        return barcorespuesta;
    }

    @Override
    public BarcosRespuesta obtenerTodosLosbarcos() {
        BarcosRespuesta barcosRespuesta=new BarcosRespuesta();
        List<Barcos> barcos = barcosRepositorio.findAll();
        
        List<BarcosDTO> barcosDTO = new ArrayList<>();
        
        for(Barcos b:barcos){
            barcosDTO.add(mapearDTO(b));
        }
        barcosRespuesta.setSalidasTodas(barcosDTO);
        return barcosRespuesta;
        //return socios.stream().map(socios -> );
    }

    @Override
    public List<BarcosDTO> obtenerTodosLosbarcosLista() {
        List<Barcos> barcos = barcosRepositorio.findAll();

        List<BarcosDTO> barcosDTO = new ArrayList<>();

        for(Barcos b:barcos){
            barcosDTO.add(mapearDTO(b));
        }

        return barcosDTO;
    }

    @Override
    public BarcosDTO obtenerBarcoPorMatricula(String matricula) {
        Barcos barco = barcosRepositorio.findById(matricula).orElseThrow(() -> new ResourceNotFoundException("Barco", "matricula", matricula));
        return mapearDTO(barco);
    }

    @Override
    public void eliminarBarco(String matricula) {
        Barcos barco = barcosRepositorio.findById(matricula).orElseThrow(() -> new ResourceNotFoundException("Barco", "matricula", matricula));
        barcosRepositorio.delete(barco);

    }



    /*



    MAPEO



     */
    private BarcosDTO mapearDTO(Barcos barco){

        return modelMapper.map(barco,BarcosDTO.class);
    }
    private Barcos mapearEntidad(BarcosDTO barcosDTO){
        return modelMapper.map(barcosDTO,Barcos.class);
    }


}
