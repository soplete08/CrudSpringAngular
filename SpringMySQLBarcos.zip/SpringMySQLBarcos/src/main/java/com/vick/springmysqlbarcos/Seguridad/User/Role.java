package com.vick.springmysqlbarcos.Seguridad.User;

public enum Role {
    ADMIN,
    USER
}
