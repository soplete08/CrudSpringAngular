package com.vick.springmysqlbarcos.dto;

import java.util.List;

public class BarcosRespuesta {
    private List<BarcosDTO> barcosTodas;

    public List<BarcosDTO> getSalidasTodas() {
        return barcosTodas;
    }

    public void setSalidasTodas(List<BarcosDTO> barcosTodas) {
        this.barcosTodas = barcosTodas;
    }
}
