package com.vick.springmysqlbarcos.Datos;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "Barco")
public class Barcos implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @NotNull
    @Column
    private String matricula;

    @Column
    @NotNull
    private String nombre;

    @Column
    private int nAmarre;

    @Column
    private float cuota;

    @ManyToOne
    @JoinColumn(name = "idSocio")
    private Socios idSocio;

    @OneToMany(mappedBy = "matriculas", cascade = CascadeType.ALL,fetch = FetchType.EAGER)
    private List<Salidas> SalidasList= new ArrayList<>();

    public Barcos() {
    }

    public Barcos(int idSocio, String matricula, String nombre, int nombreAmarre, float cuota) {
        this.matricula = matricula;
        this.nombre = nombre;
        this.nAmarre = nombreAmarre;
        this.cuota = cuota;
    }


    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getnAmarre() {
        return nAmarre;
    }

    public void setnAmarre(int nAmarre) {
        this.nAmarre = nAmarre;
    }

    public float getCuota() {
        return cuota;
    }

    public void setCuota(float cuota) {
        this.cuota = cuota;
    }

    public Socios getIdSocio() {
        return idSocio;
    }

    public void setIdSocio(Socios idSocio) {
        this.idSocio = idSocio;
    }

    public List<Salidas> getSalidasList() {
        return SalidasList;
    }

    public void setSalidasList(List<Salidas> salidasList) {
        SalidasList = salidasList;
    }

    @Override
    public String toString() {
        return "Barco " + nombre + " tiene la matricula "+ matricula+" y es de "+idSocio.getNombre()+ "\n";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Barcos barcos = (Barcos) o;
        return nAmarre == barcos.nAmarre && Float.compare(cuota, barcos.cuota) == 0 && Objects.equals(matricula, barcos.matricula) && Objects.equals(nombre, barcos.nombre);
    }

    @Override
    public int hashCode() {
        return Objects.hash(matricula, nombre, nAmarre, cuota);
    }
}
