package com.vick.springmysqlbarcos.Datos;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
@Entity
@Table(name = "socios",uniqueConstraints = {@UniqueConstraint(columnNames = {"id"})})
public class Socios implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column
    private int id;

    @Column
    @NotNull
    private String nombre;

    @Column
    @NotNull
    private int telefono;

    @OneToMany(mappedBy = "idSocio", cascade = CascadeType.PERSIST)
    private List<Barcos> barcosList= new ArrayList<>();




    public Socios() {
    }

    public Socios(int id, String nombre, int telefono) {

        this.nombre = nombre;
        this.telefono=telefono;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public List<Barcos> getBarcosList() {
        return barcosList;
    }

    public void setBarcosList(List<Barcos> barcosList) {
        this.barcosList = barcosList;
    }

    @Override
    public String toString() {
        return "Socio " + nombre + " tiene el id "+ id+"\n";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Socios socios = (Socios) o;
        return id == socios.id && Objects.equals(nombre, socios.nombre);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, nombre);
    }
}
